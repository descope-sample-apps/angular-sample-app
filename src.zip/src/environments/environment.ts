export const environment = {
  production: false,
  descopeProjectId: 'P2mqgnnsSCNr9AhSFhfMhoBWO1CL',
  baseURL: "https://api.descope.com"
};
