import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { descopeAuthGuard } from '@descope/angular-sdk';
import { MyUserProfileComponent } from './my-user-profile/my-user-profile.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'my-user-profile', component: MyUserProfileComponent },
  { path: 'dashboard',
    component: DashboardComponent,
    canActivate: [descopeAuthGuard],
		data: { descopeFallbackUrl: '/login' }
  },
  { path: '', component: HomeComponent, pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
