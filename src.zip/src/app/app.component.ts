import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css','./my-user-profile/my-user-profile.css']
})
export class AppComponent {
  title = 'my-angular-app';

}
