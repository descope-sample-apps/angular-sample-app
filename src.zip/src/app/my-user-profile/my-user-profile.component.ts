import { Component, inject } from '@angular/core';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { DescopeAuthService } from '@descope/angular-sdk';

@Component({
  selector: 'app-my-user-profile',
  templateUrl: './my-user-profile.component.html',
  styleUrls: ['./my-user-profile.css']
})
export class MyUserProfileComponent {
  private authService = inject(DescopeAuthService);
  theme = 'os';
  debugMode = true;

  onLogout(e: CustomEvent) {
    console.log('SUCCESSFULLY LOGGED IN FROM WEB COMPONENT', e.detail);
    this.router.navigate(['/login']).catch((err) => console.error(err));
  }

  constructor(private router: Router) {}
}
